<?php
defined('_VALID') or die('Restricted Access!');
$config['db_type'] = 'mysql';
$config['db_host'] = 'localhost';
$config['db_user'] = '';
$config['db_pass'] = '';
$config['db_name'] = '';
?>
