<?php
defined('_VALID') or die('Restricted Access!');

define('AVS_VERSION', '6.0');
define('AVS_PATCHLEVEL', '0');
?>
