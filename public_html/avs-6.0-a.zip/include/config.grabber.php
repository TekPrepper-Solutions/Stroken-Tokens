<?php
defined('_VALID') or die('Restricted Access!');
$sites      = array();
?>
