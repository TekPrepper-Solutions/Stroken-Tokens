<?php
defined('_VALID') or die('Restricted Access!');

$templates = array();

$templates['bright-blue'] = 'Bright/Blue';
$templates['bright-corai'] = 'Bright/Corai';
$templates['bright-corai-alternate'] = 'Bright/Corai Alternate';
$templates['bright-green'] = 'Bright/Green';
$templates['bright-magenta'] = 'Bright/Magenta';
$templates['bright-mint'] = 'Bright/Mint';
$templates['bright-orange'] = 'Bright/Orange';
$templates['bright-purple'] = 'Bright/Purple';
$templates['dark-blue'] = 'Dark/Blue';
$templates['dark-corai'] = 'Dark/Corai';
$templates['dark-green'] = 'Dark/Green';
$templates['dark-magenta'] = 'Dark/Magenta';
$templates['dark-magenta-alternate'] = 'Dark/Magenta Alternate';
$templates['dark-orange'] = 'Dark/Orange';
$templates['dark-red'] = 'Dark/Red';

?>