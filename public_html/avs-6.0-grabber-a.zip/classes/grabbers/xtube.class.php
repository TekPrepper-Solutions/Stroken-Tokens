<?php

class VGrab_xtube
{
    var $url;
    var $page;
    var $curl;
	
    function __construct() {
        $this->curl = new VCurl();
    }

    function VGrab_xtube() {
        $this->__construct();
    }

    function getPage($url) {
        $this->url  = $url;
        if ( $this->page = $this->curl->saveToString($url) ) {
            $this->page = trim($this->page);
            $this->page = str_replace("\n", '', $this->page);
            $this->page = str_replace("\r", '', $this->page);
            $this->page = preg_replace('/\s\s+/', ' ', $this->page);
            return true;
        }
        return false;
    }
	
    function getVideoID() {
        preg_match('/name="video_id" value="(.*?)"/', $this->page, $matches);		
        if ( isset($matches['1']) ) {
			$vid = $matches['1'];
			return $vid;
		}
    }
	
    function getVideoTitle() {
        preg_match('/<title>(.*?)<\/title>/', $this->page, $matches);		
        if ( isset($matches['1']) ) {
			$title = current(explode(' | ', $matches['1']));
			return $title;
		}
    }
	
	function getVideoDescription() {
        preg_match('/"cntBox contentInfo">(.*?)<p>(.*?)<\/p/', $this->page, $matches);
        if ( isset($matches['2']) ) {
			return trim(htmlspecialchars_decode(strip_tags(stripslashes($matches['2'])), ENT_QUOTES));
        }
	}
	
	function getVideoTags() {
        preg_match('/Tags:<(.*?)<\/dl>/', $this->page, $matches);		
        if ( isset($matches['1']) ) {
            $tag_string = $matches['1'];
            preg_match_all('/">(.*?)<\/a>/', $tag_string, $matches_tag);
            if ( isset($matches_tag['1']) ) {
                $tag_links  = $matches_tag['1'];
                foreach ( $tag_links as $tag ) {					
                    $tags[] = strtolower(str_replace(" ", "-", $tag));
                }
                return implode(' ', $tags);
            }
        }
	}

    function getVideoCategory() {
        preg_match('/<b>Categories:<\/b>(.*?)<\/p>/', $this->page, $matches);		
        if ( isset($matches['1']) ) {			
            $category_string = $matches['1'];
            preg_match_all('/">(.*?)<\/a>/', $category_string, $matches_category);
            if ( isset($matches_category['1']) ) {
                return implode(' ', $matches_category['1']);
            }
        }
    }
 
    function getVideoUrl() {
		preg_match('/sources":{(.*?)}/', $this->page, $matches);
		if ( isset($matches['1']) ) {
			preg_match_all('/"(.*?)":"(.*?)"/', $matches['1'], $matches_url);
			foreach ($matches_url[2] as $k => $v) {
				$videos[$matches_url[1][$k]] = str_replace("25&hash","2525&hash",stripslashes($v));
			}
			ksort($videos);			
			return $videos;
		}
    }
}

?>